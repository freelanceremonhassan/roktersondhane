<?php

use App\Http\Controllers\adminPanelController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\BlogPostController;
use App\Http\Controllers\bodyController;
use App\Http\Controllers\DonarController;
use App\Http\Controllers\donarPostController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\profileController;
use App\Http\Controllers\SearchDonarController;
use App\Http\Controllers\successRegistration;
use App\Http\Controllers\testController;
use App\Http\Controllers\UserRegistrationController;
use App\Http\Controllers\welcomePageController;
use App\Http\Livewire\AdminPanel;
use App\Http\Livewire\Login;
use App\Http\Livewire\MainBody;
use App\Http\Livewire\Register;
use App\Http\Livewire\Search;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [welcomePageController::class, 'welcomePage']);


Route::post('/login-user', [LoginController::class, 'loginUser']);
Route::get('/login', [LoginController::class, 'sessionLogin']);
Route::get('/register', Register::class);
Route::get('/body/{id}', [bodyController::class, 'donarBody']);
Route::get('/profile/{id}', [profileController::class, 'DonarProfile']);
Route::get('/blog/{id?}', [BlogController::class, "showBlogPost"]);
Route::get('/admin-panel', AdminPanel::class);
Route::post('/donar-registration', [UserRegistrationController::class, 'userRegistration']);
Route::post('/donar-post', [donarPostController::class, 'createPost']);
Route::get('/test', [testController::class, 'textControllingSystem']);
Route::get('/search-donar',[SearchDonarController::class, 'searchDonar']);
Route::post('/blog-post',[BlogPostController::class, 'blogPost']);
