function previewProfileImage(input){
    var file = $("input[type=file]").get(0).files[0];
    if(file){
        var reader = new FileReader();
        reader.onload = function(){
            $('#preview_profile_image').attr('src', reader.result);
        }
        reader.readAsDataURL(file);
    }
}

$(document).ready(function(){
    $(window).scroll(function(){
        if ($(this).scrollTop()>80) {
            $('#topBtn').fadeIn();
            $('#topBtn').removeClass('d-none');
        }else{
            $('#topBtn').fadeOut()
        }
    });

    $('#topBtn').click(function(){
        $('html, body').animate({scrollTop : 0}, 20);
    });
});