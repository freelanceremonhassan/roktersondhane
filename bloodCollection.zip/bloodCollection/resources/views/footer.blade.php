   @livewireScripts
    <script src="{{ url('assets/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ url('assets/fontawesome/js/all.min.js') }}"></script>
    <script src="{{ url('assets/sweetalert.min.js') }}"></script>
    <script src="{{ url('assets/javascript.js') }}"></script>
@if (Session::has('succ_message'))
    <script>
        swal("Great Job..!", "{!! Session::get('succ_message') !!}", "success", {
            button:"OK",
        })
    </script>
    @elseif (Session::has('err_message'))
    <script>
        swal("Sorry..!", "{!! Session::get('err_message') !!}", "error", {
            button:"OK",
        })
    </script>
@endif
</body>
</html>