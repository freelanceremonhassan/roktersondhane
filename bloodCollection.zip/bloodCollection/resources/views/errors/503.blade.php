@include('header')

<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="text-center">
                <img src="{{ asset('loader/undermaintenance.gif') }}" alt="Website is in Under Maintenence">
            </div>
            <h1 class="text-center text-muted">Site Under Maintenance</h1>
            <p class="text-secondary text-center">We are currently under maintenance. We will be back shortly. Thank you for your patience.</p>
        </div>
    </div>
</div>

@include('footer')