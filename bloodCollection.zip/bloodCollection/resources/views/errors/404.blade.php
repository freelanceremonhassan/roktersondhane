@include('header')

<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2 text-center mt-5">
            <h1 style="font-size:120px">404</h1>
            <p class="text-muted">Your requested page isn't found. Sorry for your patience.</p>
            <p class="text-secondary">Please go to homepage.<p>
            <a href="/" class="btn btn-success">Go to Home Page</a>
        </div>
    </div>
</div>

@include('footer')