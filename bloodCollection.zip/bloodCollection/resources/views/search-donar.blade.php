@extends('layouts.master')
@section('title', 'Search Result')
@section('content')
    

    <div class="container">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <div class="col-12 row mb-3 pt-3">
                    <div class="col-12 text-center">
                        <a href="/" class="text-danger"><span><<</span> Go To Home Page</a>
                    </div>
                </div>
                
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Blood Group</th>
                            <th>District</th>
                            <th>Thana</th>
                            <th>Call Donar</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($blood as $donar)
                            <tr>
                                <td>{{ $donar->name }}</td>
                                <td>{{ $donar->blood_group }}</td>
                                <td>{{ $donar->district }}</td>
                                <td>{{ $donar->thana }}</td>
                                <td><a href="tel:{{ $donar->phone }}" class="btn btn-primary"><i class="fa fa-phone"></i> Call</a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <button class="btn btn-warning d-none" id="topBtn"><i class="fa fa-arrow-up"></i></button>
    </div>


@endsection