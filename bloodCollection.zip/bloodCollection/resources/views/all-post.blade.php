@extends('layouts.master')
@section('title', 'Blog Posts')
@section('content')
    
    
    <div class="container">
        <div class="text-end pt-3">
            <a href="/"><span><< </span>Go Back to Home</a>
        </div>
        @foreach ($post as $item)
            <div class="mb-2">
                <h5 class="text-center text-danger" style="text-decoration: underline">{{ $item->title }}</h5>
                @if ($item->blog_image)
                    <img src="{{ asset('images/blog_images') }}/{{ $item->blog_image }}" alt="{{ $item->title }}" style="float:left; width: 200px; height: 200px; margin-right: 5px;">
                @endif
                <p class="text-dark" style="font-family: tahoma; font-size: 12pt">
                    {{ $item->blog_content }}
                </p>
            </div>
            <hr class="text-danger">
        @endforeach
        {{ $post->links() }}
    </div>
    <footer class="text-center container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">MD EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">MD EMON HASSAN</a></i></div>
        </div>
    </footer>

@endsection