<div>
    @extends('layouts.master')
    @section('title', 'Donar Registration')

    <div class="container mb-5 mb-sm-5 pb-5 pb-sm-1">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="text-end pt-4">
                    <a href="/"><span><< </span>Go Back to Home</a>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center"><i class="fa fa-heartbeat text-danger"></i> <span class="text-success">Donar Registration Form</span></h4>
                    </div>
                    <div class="card-body">
                        <form action="/donar-registration" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label for="name">Full Name:</label>
                                <input type="text" name="name" id="name" class="form-control" wire:model='name' required>
                                @error('name')
                                    <p class="text-danger">{{ $message }}</p>
                                @enderror
                            </div>
                            <div class="form-group mt-sm-2">
                                <label for="email">E-mail</label>
                                <input type="email" name="email" id="email" class="form-control" wire:model="email">
                                @error('email')
                                    <p class="text-danger">{{ $message }}</p>
                                @enderror
                            </div>
                            <div class="form-group mt-sm-2">
                                <label for="phone">Phone Number</label>
                                <input type="text" name="phone" id="phone" class="form-control" wire:model="phone" required>
                                @error('phone')
                                    <p class="text-danger">{{ $message }}</p>
                                @enderror
                            </div>
                            <div class="form-group mt-sm-2">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" class="form-control" wire:model="password" required>
                                @error('password')
                                    <p class="text-danger">{{ $message }}</p>
                                @enderror
                            </div>
                            <div class="form-group mt-sm-2 row">
                                <div class="col-sm-8">
                                    <label for="profile_picture" class="align-middle">Profile Picture</label>
                                    <input type="file" name="image" id="profile_picture" class="form-control align-middle" onchange="previewProfileImage(this)" wire:model="image" required>
                                    @error('image')
                                        <p class="text-danger">{{ $message }}</p>
                                    @enderror
                                </div>
                                <div class="col-sm-4 text-center">
                                    <img id="preview_profile_image" style="width: 150px; height: 150px;border-radius: 50%; object-fit: fill" wire:ignore.self>
                                </div>
                            </div>
                            <div class="form-group mt-sm-2 row">
                                <label for="address">Address</label>
                                <div class="col-sm-3">
                                    <input type="text" name="division" id="address" placeholder="Division" class="form-control" wire:model='division' required>
                                    @error('division')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                                <div class="col-sm-3 mt-2 mt-sm-0">
                                    <input type="text" name="district" id="address" placeholder="District" class="form-control" wire:model="district" required>
                                    @error('district')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                                <div class="col-sm-3 mt-2 mt-sm-0">
                                    <input type="text" name="thana" id="address" class="form-control" placeholder="Thana" wire:model="thana" required>
                                    @error('thana')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                                <div class="col-sm-3 mt-2 mt-sm-0">
                                    <input type="text" name="post_office" id="address" class="form-control" placeholder="Post-Office" wire:model="post_office">
                                    @error('post_office')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row mt-sm-2">
                                <div class="col-sm-3">
                                    <label for="age">Age</label>
                                    <input type="text" name="age" id="age" class="form-control" wire:model="age" required>
                                    @error('age')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                                <div class="col-sm-3">
                                    <label for="weight">Weight</label>
                                    <input type="text" name="weight" id="weight" class="form-control" wire:model="weight" required>
                                    @error('weight')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                                <div class="col-sm-3">
                                    <label for="blood_grp">Blood</label>
                                    <select name="blood_group" id="blood_grp" class="form-control" required>
                                        <option value="Select One" disabled selected>Select One</option>
                                        <option value="A+">A+</option>
                                        <option value="A-">A-</option>
                                        <option value="B+">B+</option>
                                        <option value="B-">B-</option>
                                        <option value="O+">O+</option>
                                        <option value="O-">O-</option>
                                        <option value="AB+">AB+</option>
                                        <option value="AB-">AB-</option>
                                    </select>
                                    @error('blood_group')
                                        <p class="text-danger">invalid</p>
                                    @enderror
                                </div>
                                <div class="col-sm-3">
                                    <label for="ldobd">Last Donate</label>
                                    <input type="date" name="last_donate" id="ldobd" class="form-control">
                                </div>
                            </div>
                            <div class="text-center">
                                <input type="button" data-toggle="modal" data-target="#terms_and_condition" value="Register" class="btn btn-outline-info w-50 mt-2 mt-sm-3">
                            </div>
                            <!--Terms and Condition Modal -->
                            <div class="modal fade" id="terms_and_condition" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="terms_and_conditionLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                                <div class="modal-content">
                                    <div class="card-header">
                                    <h5 class="modal-title text-center" id="terms_and_conditionLabel">Terms and Condition</h5>
                                    </div>
                                    <div class="modal-body">
                                        <p class="text-muted">
                                            <h6 class="text-center text-danger">"রক্তের সন্ধানে" আপনাদের সবাইকে স্বাগতম।</h6>
                                            আপনারা সবাই জানেন রক্ত তৈরি করা যায়না। একজনের শরীর থেকে রক্ত নিয়ে অন্যজনের শরীরে দেওয়া হয়। তাই যখনই আমাদের রক্তের প্রয়োজন হয় আমরা পাগলের মত রক্ত খুঁজতে থাকি। কিন্তু আমাদেরই পাশের কোন মানুষের রক্তের প্রয়োজন পড়লে তাকে রক্ত দিয়ে সাহায্য করা তো দূরে থাক বিভিন্ন অজুহাতে সেখান থেকে পালানোর চেষ্টা করি। কিন্তু একবার ভেবে দেখুন তো আপনার নিজের কারো রক্তের প্রয়োজন হলে আপনি সেদিন কি করবেন? আজ আপনি কাউকে সাহায্য করলে আপনার বিপদে হাজারো মানুষ ঝাপিয়ে পরবে। তাই, <br>
                                            <ol>
                                                <li>"রক্তের সন্ধানে" আপনি নিজে রক্ত দেওয়ার জন্য প্রস্তুত থাকলে তবেই কেবল রেজিস্ট্রেশান করবেন।</li>
                                                <li>আপনার রক্তের প্রয়োজন পড়লে প্রথমেই "রক্তের সন্ধানে" খুঁজবেন। </li>
                                                <li>"রক্তের সন্ধানে" সম্পর্কে আপনার বন্ধু-বান্ধবদের জানাবেন যাতে তারাও প্রয়জনে উপকৃত হতে পারে।</li>
                                                <li>কাউকে কোনোপ্রকার কটূক্তি, খারাপ কথা বলা বা বাজে বাবহার করবেন না। আপনার সাথে কেউ এমন করলে তার পুরো তথ্যসহ আমাদের ঠিকানায় যোগাযোগ করবেন।</li>
                                                <li>গুজবে কান দিবেন না। রক্তের জন্য কাউকে টাকা দিবেন না।</li>
                                            </ol>
                                        </p>
                                        <div class="mt-3 form-check">
                                            <input type="checkbox" class="form-check-input" name="terms" id="exampleCheck1" required>
                                            <label class="form-check-label" for="exampleCheck1">Do you agree with our <span class="text-danger">terms and condition</span>?</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-success">Understood</button>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center fixed-bottom container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
        </div>
    </footer>
    
</div>
