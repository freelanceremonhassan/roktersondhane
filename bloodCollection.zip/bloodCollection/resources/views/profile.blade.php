@extends('layouts.master')
@section('title', 'View Profile')

@section('content')
    

    <div class="container">
        <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="col-12 text-end">
                        <a href="/" class="text-danger"><span><<</span> Go To Home Page</a>
                    </div>
                    @foreach ($allDonar as $information)
                        <div class="text-center mt-5">
                            <img src="{{ asset('images/profile_images') }}/{{ $information->image }}" style="width: 150px; height:150px; border-radius: 50%;" alt="" class="">
                            <p class="h5 text-dark text-center mt-3">{{ $information->name }}</p>
                        </div>
                        <div class="text-center">
                            <a href="tel:{{ $information->phone }}" class="btn btn-danger w-md-25"><i class="fa fa-phone"></i>Call Now</a>
                        </div>
                    @endforeach
                    
                    <div class="text-center mt-3">
                        <table class="table table-striped">
                            <tr class="text-danger">
                                <th>Last Donated</th>
                                <th>Available After</th>
                                <th>Donated</th>
                            </tr>
                            @foreach ($allDonar as $information)
                                <tr>
                                        @if ($information->last_donate == ""|null)
                                            <td>Null</td>
                                            @else
                                                <td>{{ $information->last_donate }}</td>
                                        @endif
                                    <td>Null</td>
                                    <td>Null</td>
                                </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
        </div>
    </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-center">Posts</h4>
                        </div>
                        <div class="card-body row">
                            @foreach ($selectedDonar as $donarPost)
                                @foreach ($allDonar as $item)
                                    @if ($donarPost->id == $item->id)
                                        <div class="card posts">
                                            <a href="#" data-toggle="modal" data-target="#view_post_modal"><img src="{{ asset('images/post_image') }}/{{ $donarPost->post_image }}" alt="{{ $item->name }}" class="card-img-top" style="height:150px"></a>
                                        </div>
                                    @endif
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <footer class="text-center fixed-bottom container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
        </div>
    </footer>


@endsection