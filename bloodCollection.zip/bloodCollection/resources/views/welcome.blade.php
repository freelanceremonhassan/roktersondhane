@extends('layouts.master')
@section('title', "Welcome to Rokter Sondhane")
@section('content')
    

<div class="container my-4">
    <div class="col-md-12 row">
        <div class="col-md-3 col-12 text-center">
            <a href="/"><img src="{{ url("images/logo/WDC.jpg") }}" style="width:100px; height: 100px; border-radius: 50%;" alt="Rokter Sondhane"></a>
        </div>
        <div class="col-md-5 mt-md-2 col-12 mt-2">
           <h5 class="text-success text-center"><span style="color:rgb(39, 156, 39);">রক্ত দিন,</span><span style="color: rgb(35, 52, 199);"> সুস্থ থাকুন,</span><span style="color: rgb(219, 91, 91);"> সুস্থ রাখুন</span></h5>
        </div>
        <div class="col-md-4 text-md-end mt-md-2 col-12 text-center">
            <a href="/login"><i class="fa fa-sign-in-alt mt-1"></i> Login</a> <span>|</span>
            <a href="/register"><i class="fa fa-user-plus"></i> Register</a>
        </div>
    </div>
</div>
<hr>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-center">Blood Fighters</h4>
                </div>
                <div class="card-body row">
                    @foreach ($allPost as $item)
                        <div class="card posts">
                            <img src="{{ asset('images/post_image') }}/{{ $item->post_image }}" alt="Mr. Emon Khan" class="card-img-top" style="height:150px">
                            <div class="card-body">
                                <div class="card-title text-center fw-bold">{{ $item->name }}</div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="text-center fixed-bottom container-fluid">
    <div class="bg-light row">
        <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
        <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
    </div>
</footer>


@endsection