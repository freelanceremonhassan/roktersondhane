@extends('layouts.master')
    @section('title', 'Donar Login')

    @section('content')
    <div class="container" wire:ignore.self>
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="text-end pt-4">
                    <a href="/"><span><< </span>Go Back to Home</a>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center"><i class="fa fa-hand-holding-heart text-danger"></i> <span class="text-success">Donar Login</span></h4>
                    </div>
                    <div class="card-body">
                        <div class="container">
                            <form action="/login-user" method="post">
                                @csrf
                                <div class="col-md-12 row form-group">
                                    <div class="col-md-5 text-md-center">
                                        <label for="phone">Phone:</label>
                                    </div>
                                    <div class="col-md-7">
                                        <input type="text" name="phone" wire:model="phone" value="{{ session('donar_phone') }}" id="phone" class="form-control" required>
                                        @error('phone')
                                            <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-12 mt-md-3 mt-2 text-md-center row form-group">
                                    <div class="col-md-5">
                                        <label for="password">Password:</label>
                                    </div>
                                    <div class="col-md-7">
                                        <input type="password" name="password" wire:model="password" value="{{ session('donar_password') }}" id="password" class="form-control" required>
                                        @error('password')
                                            <p class="text-danger text-start">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-12 mt-md-3 mt-3 text-center">
                                    <input type="submit" value="Login" class="btn btn-outline-success w-25">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center fixed-bottom container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
        </div>
    </footer>
    @endsection