@include('header')
    {{ $slot }}
@include('footer')