<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BlogController extends Controller
{
    public function showBlogPost($id = null){
        $post = DB::table('blogs')->orderBy('id','DESC')->paginate(5);
        if ($id) {
            $post = DB::table('blogs')->where('id', $id)->orderBy('id','DESC')->paginate(5);
            return view('all-post', compact('post'));
        }
        return view('all-post', compact('post'));
    }
}
