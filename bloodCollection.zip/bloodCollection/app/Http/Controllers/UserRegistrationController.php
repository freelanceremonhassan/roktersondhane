<?php

namespace App\Http\Controllers;

use App\Models\Division;
use App\Models\UserRegistation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Intervention\Image\Facades\Image;

class UserRegistrationController extends Controller
{
    public function userRegistration(Request $req){
        $image = $req->file('image');
        $imageName = $image->getClientOriginalName();
        $imageNewName = $imageName.time().'.'.$image->extension();
        $image_resize = Image::make($image->getRealPath());

        $donar = UserRegistation::where('phone', $req->phone)->get();
        foreach ($donar as $key) {
            if ($key->phone == $req->phone) {
                return redirect('/register')->with('err_message', 'You are already registered..!');
            }
        }

        $image_resize->resize(300, 300);
        $image_resize->save(public_path('images/profile_images/'. $imageNewName));
        UserRegistation::insert([
            'name'=>$req->name,
            'email'=>$req->email,
            'phone'=>$req->phone,
            'password'=>$req->password,
            'image'=>$imageNewName,
            'division'=>$req->division,
            'district'=>$req->district,
            'thana'=>$req->thana,
            'post_office'=>$req->post_office,
            'age'=>$req->age,
            'weight'=>$req->weight,
            'blood_group'=>$req->blood_group,
            'last_donate'=>$req->last_donate
        ]);
        return redirect('/login')->with('succ_message', "Now you are the member of 'Rokter Sondhane'");
        
        
        
    }
}
