<?php

namespace App\Http\Controllers;

use App\Models\donarPost;
use Illuminate\Http\Request;

class welcomePageController extends Controller
{
    public function welcomePage(){
        //Using session
        $id = session('donar_id');
        $phone = session('donar_phone');
        $password = session('donar_password');
        
        if (isset($phone) && isset($password)) {
            return redirect("/body/{$id}");
        }else{
            //Home Page data
            $allPost = donarPost::join('user_registations', 'user_registations.id', '=', 'donar_posts.donar_id')
            ->select('user_registations.name', 'donar_posts.post_image', 'donar_posts.id')
            ->orderBy('donar_posts.id', 'DESC')->paginate(10);
            return view('welcome', compact('allPost'));
        }

        
    }
}
