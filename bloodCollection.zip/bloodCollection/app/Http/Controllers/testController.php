<?php

namespace App\Http\Controllers;

use App\Models\UserRegistation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class testController extends Controller
{
    public function textControllingSystem(){
         $user = 21;
        if (isset($user)) {
            $donar = UserRegistation::where('blood_group', 'B+')
                                ->where('thana', 'Kumarkhali')
                                ->where('age', $user)
                                ->get();
        }else{
            $donar = UserRegistation::where('blood_group', 'B+')
                                ->get();
        }
        return $donar;
    }
}
