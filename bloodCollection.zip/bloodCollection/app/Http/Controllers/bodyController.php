<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\UserRegistation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class bodyController extends Controller
{
    public function donarBody($id){
       $selectedDonar = UserRegistation::where('id', $id)->get();
       $allDonars = UserRegistation::all();
       $donarPosts = DB::table('user_registations')
                    ->join('donar_posts', 'user_registations.id', '=', 'donar_posts.donar_id')
                    ->select('user_registations.name', 'user_registations.thana', 'user_registations.district', 'user_registations.image','donar_posts.id', 'donar_posts.post_image', 'donar_posts.post_content')
                    ->orderBy('donar_posts.id', 'DESC')
                    ->paginate(5);
        $allpost = Blog::orderBy('id', 'DESC')->paginate(6);
       return view('main-body', compact('selectedDonar', 'allDonars', 'donarPosts', 'allpost'));
    }
}
