<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserRegistation;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function sessionLogin(){
        $id = session('donar_id');
        $phone = session('donar_phone');
        $password = session('donar_password');
        
        if (isset($phone) && isset($password)) {
            return redirect("/body/{$id}");
        }else{
            return view('login');
        }

    } 
    
    public function loginUser(Request $req){
        $donar =new UserRegistation();
        if ($req->phone == '0123456789' && $req->password == 'admin@admin') {
            return redirect('/admin-panel');
        }
        $selectedDonar = $donar->where('phone', $req->phone)->get();
        foreach ($selectedDonar as $key) {
            if ($key->phone == $req->phone && $key->password==$req->password) {
                session()->put('donar_phone', $key->phone);
                session()->put('donar_password', $key->password);
                session()->put('donar_id', $key->id);
                return redirect("/body/{$key->id}");
            }else{
                return redirect('/login')->with('err_message', "Phone or Password is wrong.!");
            }
        }
    }
}
