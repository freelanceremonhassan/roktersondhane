<?php

namespace App\Http\Controllers;

use App\Models\UserRegistation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class profileController extends Controller
{
    public function DonarProfile($id){
        $allDonar = UserRegistation::where('id', $id)->get();
        $selectedDonar = UserRegistation::join('donar_posts', 'donar_posts.donar_id', '=', 'user_registations.id')
                ->select('user_registations.id', 'donar_posts.donar_id', 'donar_posts.post_image')
                ->get();

        return view('profile', compact('selectedDonar', 'allDonar'));
    }
}
