<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class BlogPostController extends Controller
{
    public function blogPost(Request $req){
        if ($req->blog_image) {
            $image = $req->file('blog_image');
            $imageName = $image->getClientOriginalName();
            $imageNewName = $imageName.time().'.'.$image->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(300, 300);
            $image_resize->save(public_path('images/blog_images/'. $imageNewName));
            Blog::insert([
                'title'=>$req->blog_title,
                'blog_image'=>$imageNewName,
                'blog_content'=>$req->blog_content
            ]);
            return back()->with('succ_message', 'Blog Post has been successfully created..!');
        }else {
            Blog::insert([
                'title'=>$req->blog_title,
                'blog_content'=>$req->blog_content
            ]);
            return back()->with('succ_message', 'Blog Post has been successfully created..!');
        }
        
    }
}
