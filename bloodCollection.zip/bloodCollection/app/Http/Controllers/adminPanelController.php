<?php

namespace App\Http\Controllers;

use App\Models\UserRegistation;
use Illuminate\Http\Request;

class adminPanelController extends Controller
{
    public function adminPanel(){
        $donars = UserRegistation::orderBy('id','DESC')->paginate(10);
        return view('admin-panel', compact('donars'));
    }
}
