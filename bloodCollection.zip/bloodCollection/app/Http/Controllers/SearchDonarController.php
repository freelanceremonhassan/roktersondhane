<?php

namespace App\Http\Controllers;

use App\Models\UserRegistation;
use Illuminate\Http\Request;

class SearchDonarController extends Controller
{
    public function searchDonar(Request $req){
        $allDonars = new UserRegistation();
        $district = "%".$req->district."%";
        $thana = "%".$req->thana."%";
        if (isset($thana)) {
            $blood = $allDonars->where('blood_group', 'LIKE', $req->blood_grp)
                            ->where('district', 'LIKE', $district)
                            ->where('thana', 'LIKE', $thana)
                            ->get();
            return view('search-donar', compact('blood'));
        }else{
            $blood = $allDonars->where('blood_group', 'LIKE', $req->blood_grp)
                            ->where('district', 'LIKE', $district)
                            ->get();
            return view('search-donar', compact('blood'));
        }
    
    }
}
