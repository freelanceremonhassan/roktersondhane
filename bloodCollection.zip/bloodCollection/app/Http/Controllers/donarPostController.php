<?php

namespace App\Http\Controllers;

use App\Models\donarPost;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class donarPostController extends Controller
{
    public function createPost(Request $req){
        if ($req->post_image) {
            $image = $req->file('post_image');
            $imageName = $image->getClientOriginalName();
            $imageNewName = $imageName. time().'.'.$image->extension();
            $image_resize = Image::make($image->getRealPath());
            $image_resize->resize(350,300);
            $image_resize->save(public_path('images/post_image/'. $imageNewName));

            donarPost::insert([
                'post_image'=>$imageNewName,
                'post_content'=>$req->post_content,
                'donar_id'=>$req->donar_id
            ]);
            return back();
        }else {
            return "Something went wrong";
        }

        
    }
}
