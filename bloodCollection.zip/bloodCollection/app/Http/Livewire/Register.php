<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;

class Register extends Component
{
    use WithFileUploads;
    public $name;
    public $email;
    public $phone;
    public $password;
    public $image;
    public $division;
    public $district;
    public $thana;
    public $post_office;
    public $age;
    public $weight;
    public $blood_group;

    public function submitForm(){
        $this->validate([
            'name'=>'required',
            'email'=>'email',
            'phone'=>'required|min:10|max:13|digits_between:10,13',
            'password' =>'required|min:6|max:12',
            'image'=>'required|image',
            'division'=>'required',
            'district'=>'required',
            'thana'=>'required',
            'post_office'=>'required',
            'age'=>'required|digits:2',
            'weight'=>'required|digits_between:2,3',
            'blood_group'=>'required',
        ]);
    }
    public function updated($fields){
        $this->validateOnly($fields,[
            'name'=>'required',
            'email'=>'email',
            'phone'=>'required|min:10|max:13|digits_between:10,13',
            'password' =>'required|min:6|max:12',
            'image'=>'required|image',
            'division'=>'required',
            'district'=>'required',
            'thana'=>'required',
            'post_office'=>'required',
            'age'=>'required|digits:2',
            'weight'=>'required|digits_between:2,3',
            'blood_group'=>'required',
        ]);
    }

    public function render()
    {
        return view('livewire.register');
    }
}
