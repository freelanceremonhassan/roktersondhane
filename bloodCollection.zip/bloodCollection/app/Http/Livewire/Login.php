<?php

namespace App\Http\Livewire;

use App\Models\UserRegistation;
use Livewire\Component;

class Login extends Component
{
    public $phone;
    public $password;

    public function updated($fields){
        $this->validateOnly($fields,[
            'phone' => 'required|min:8|max:15|digits_between:8, 15',
            'password' =>'required|min:6|max:12'
        ]);
    }
    public function submitForm(){
        $this->validate([
            'phone' => 'required|min:8|max:15|digits_between:8, 15',
            'password' =>'required|min:6|max:12'
        ]);
    }

    public function render()
    {
        $id = session('donar_id');
        $phone = session('donar_phone)');
        $password = session('donar_password');
        return $phone;
        return view('livewire.login');
    }
}
