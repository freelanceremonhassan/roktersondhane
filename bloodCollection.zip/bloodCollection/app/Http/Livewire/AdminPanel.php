<?php

namespace App\Http\Livewire;

use App\Models\UserRegistation;
use Livewire\Component;

class AdminPanel extends Component
{
    public $searchItem;
    public function render()
    {
        $searchItem = '%'.$this->searchItem.'%';
        $donars = UserRegistation::where('district', 'LIKE', $searchItem)
        ->orWhere('thana', 'LIKE', $searchItem)
        ->orWhere('blood_group', 'LIKE', $searchItem)
        ->orWhere('name', 'LIKE', $searchItem)
        ->orderBy('id','DESC')->paginate(10);
        return view('livewire.admin-panel', ['donars'=>$donars]);
    }
}
