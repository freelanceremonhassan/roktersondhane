<?php return array (
  'admin-panel' => 'App\\Http\\Livewire\\AdminPanel',
  'login' => 'App\\Http\\Livewire\\Login',
  'register' => 'App\\Http\\Livewire\\Register',
);