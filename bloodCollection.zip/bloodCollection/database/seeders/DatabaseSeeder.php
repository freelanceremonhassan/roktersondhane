<?php

namespace Database\Seeders;

use Brick\Math\BigInteger;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 100) as $index) {
            DB::table('user_registations')->insert([
                'name'=>$faker->name,
                'email'=>$faker->email,
                'phone'=>$faker->phoneNumber,
                'password'=>$faker->password,
                'image'=>$faker->name,
                'division'=>$faker->name,
                'district'=>$faker->name,
                'thana'=>$faker->name,
                'post_office'=>$faker->name,
                'age'=>$faker->numberBetween(50, 60),
                'weight'=>$faker->numberBetween(50, 60),
                'blood_group'=>$faker->randomElement(array('A+', 'A-', "B+", 'B-', 'O+', 'O-', "AB+", "AB-")),
                'last_donate'=>$faker->date($format = 'Y-m-d', $max = 'now'),
            ]);
        }
        // \App\Models\User::factory(10)->create();
    }
}
