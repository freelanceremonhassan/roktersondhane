<div>
        
        <?php $__env->startSection('title', 'Search Result'); ?>
          <section> 
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2 row">
                    <div class="col-6 pt-3">
                        <a href="/" class="text-danger"><span class="text-danger"><< </span>Go Back to Home</a>
                    </div>
                    <div class="col-md-6">
                        <div class="pt-2 input-group">
                            <input type="text" name="search_item" id="search_item" class="form-control w-75" wire:model="searchTerm">
                            <span class="input-group-text btn btn-primary">Search</span>
                        </div>
                    </div>
                    <table class="table table-striped mt-2">
                        <tr>
                            <th>Name</th>
                            <th>Blood Group</th>
                            <th>District</th>
                            <th>Thana</th>
                            <th>View Profile</th>
                        </tr>
                        <?php $__currentLoopData = $blood; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($donar->name); ?></td>
                                <td><?php echo e($donar->blood_group); ?></td>
                                <td><?php echo e($donar->district); ?></td>
                                <td><?php echo e($donar->thana); ?></td>
                                <td><a href="#" class="btn btn-primary">Profile</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </section> 
</div>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/livewire/search-donar.blade.php ENDPATH**/ ?>