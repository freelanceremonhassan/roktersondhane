<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2 text-center mt-5">
            <h1 style="font-size:120px" class="text-dark">404</h1>
            <h2 class="text-secondary">Page not found</h2>
            <p class="text-secondary">We are sorry, the page you requested could not be found. Please go back to the Home Page</p>
            <a href="/" class="btn btn-primary">Go to HomePage</a>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/errors/404.blade.php ENDPATH**/ ?>