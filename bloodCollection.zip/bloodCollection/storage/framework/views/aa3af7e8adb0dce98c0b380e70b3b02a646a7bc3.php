<div>
    
<?php $__env->startSection('title', "'Rokter Sondhane' আপনাকে স্বাগতম"); ?>

    
    <div class="container-fluid background-image">
        <div class="col-12">
            <div class="col-12 py-3 row">
                <div class="col-6 text-end">
                    <a href="/">
                        <img src="<?php echo e(url('images/logo/WDC.jpg')); ?>" style="width: 150px; height:50px; border-radius: 5%;" alt=""></a>
                </div>
                <div class="col-6 mt-2">
                    <p class="fw-bold h3 text-danger">Rokter Sondhane</p>
                </div>
            </div>
        </div>
        <div class="col-md-12 row">
            <div class="col-md-3">
                    <?php $__currentLoopData = $selectedDonar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donarData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 text-center">
                            <img src="<?php echo e(asset('images/profile_images')); ?>/<?php echo e($donarData->image); ?>" style="width: 50px; height:50px; border-radius: 50%;" alt="" class="">
                        </div>
                        <div class="col-md-12 mt-md-2 mb-md-3">
                            <p class="fw-bold h5 text-dark text-center"><?php echo e($donarData->name); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="">
                    <div class="image-half float-left">
                        <img src="<?php echo e(url('images/Uploaded Images/be-aware-of-fraud.jpg')); ?>" alt="রক্তের বিনিময়ে কেউ টাকা চাইলে বুঝে নিবেন সে প্রতারক।" class="w-100">
                    </div>
                    <div class="text-center image-half float-right">
                        <div class="custom">
                            <div style="background-color: #fff0d1; border: 1px solid red; border-radius: 10px; padding: 15px; margin-top: 5px;">
                                <p>
                                    <span style="color: #d90101; font-size: 10pt;"><strong>প্রস্তুত যদি থাকে দুইজন রক্তদাতা...</strong></span><br><span style="font-size: 12pt; color: #d90101;"><strong style="font-size: 10pt">থাকবে গর্ভবতী মায়ের প্রাণের নিশ্চয়তা...</strong></span>
                                </p>
                                <p style="font-size: 10pt">একজন গর্ভবতী মায়ের রক্তের প্রয়োজন হতে পারে এটা ডেলিভারী তারিখের ৯ মাস আগে থেকেই আপনি জানেন... সুতরাং, মনে করে আগে থেকেই ২ জন রক্তদাতা খুজে রাখুন...</p>
                                <p style="font-size: 10pt">বন্ধুবান্ধব এবং পরিচিত রক্তদাতাদের সবসময় প্রস্তুত থাকতে বলুন যেন গর্ভবতীর যেকোনো শারীরিক জটিলতায় উনারাই প্রথম এগিয়ে আসতে পারে...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group container mt-3 mt-sm-3 mt-md-0">
                    <button type="button" href="#" name="post" id="post" placeholder="Create post" class="form-control text-muted text-center" data-toggle="modal" data-target="#create_post">Create Post</button>
                    <!--Create Post Modal -->
                    <div class="modal fade" id="create_post" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="create_postLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="card-header">
                            <h5 class="modal-title text-center" id="create_postLabel">Create Post</h5>
                            </div>
                            <div class="modal-body">
                                <form action="/donar-post" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="post_image">Add an Image</label>
                                        <input type="file" name="post_image" id="post_image" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="post_content">Write Something</label>
                                        <textarea name="post_content" id="post_content" cols="30" rows="6" class="form-control" required></textarea>
                                    </div>
                                    <?php $__currentLoopData = $selectedDonar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donarID): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="donar_id" value="<?php echo e($donarID->id); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div> 
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Discard</button>
                                        <input type="submit" class="btn btn-success" value="Post">
                                    </div>
                                </form>  
                        </div>
                        </div>
                    </div>
                </div>
                <div class="container mt-md-4">
                    <?php $__currentLoopData = $donarPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donarPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3 margin-top">
                            <div class="col-12 row">
                                <div class="col-1 me-lg-2 margin-right">
                                    <img src="<?php echo e(asset('images/profile_images')); ?>/<?php echo e($donarPost->image); ?>" style="width: 50px; height:50px; border-radius: 50%;" alt="" class="">
                                </div>
                                <div class="col-11 col-lg-7 ms-lg-2 margin-left">
                                    <p class="fw-bold h5 text-dark"><?php echo e($donarPost->name); ?></p>
                                    <p style="margin-top: -10px;">From <?php echo e($donarPost->thana); ?> <?php echo e($donarPost->district); ?></p>
                                </div>
                            </div>
                            <div class="container-fluid">
                                <div class="border-body">
                                    <div style="width: 100%; text-align: justify; margin: auto;">
                                        <img src="<?php echo e(asset('images/post_image')); ?>/<?php echo e($donarPost->post_image); ?>" alt="Uploaded Image" style="width: 100%; height: 100%; display:block" class="">
                                    </div>
                                    <hr style="margin-top: 0px">
                                    <p style="padding-right:15px; padding-left:15px; text-align: justify;"><?php echo e($donarPost->post_content); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-3">
                        <div class="col-md-10 offset-md-1 text-center">
                            <?php echo e($donarPosts->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-3">
                <h5 class="text-center text-success">রক্তদাতা খুজুন (Search the Donars..)</h5>
                <form action="" method="POST">
                    <div class="col-md-12 row">
                        <div class="col-md-5 mt-md-1">
                            Blood Group:
                        </div>
                        <div class="col-md-7">
                            <div class="form-group">
                                <select name="blood_grp" id="blood_grp" class="form-control">
                                    <option value="Select One" disabled selected>Select One</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 row">
                        <div class="col-md-5 mt-md-2">District: </div>
                        <div class="col-md-7 mt-md-2 form-group">
                            <input type="text" name="search_district" id="search_district" placeholder="District" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-12 row">
                        <div class="col-md-5 mt-md-2">Thana: </div>
                        <div class="col-md-7 mt-md-2 form-group">
                            <input type="text" name="search_thana" id="search_thana" placeholder="Thana" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-12 text-center mt-2">
                        <input type="submit" value="Search" class="btn btn-outline-primary w-50">
                    </div>
                </form>
                <div class="mt-2">
                    <ol>
                        <li>Emon -<span class="text-muted">Kushtia, Kumarkhali</span></li>
                        <li>Manik -<span class="text-muted">Kushtia, Kumarkhali</span></li>
                        <li>Saad -<span class="text-muted">Kushtia, Kumarkhali</span></li>
                        <li>Hanif -<span class="text-muted">Kushtia, Kumarkhali</span></li>
                    </ol>
                </div>
                <div class="mt-md-2">
                    <table class="table table-striped">
                        <tr>
                            <th>
                                <div class="col-12 row">
                                    <div class="col-8">Recent Blog Post</div>
                                    <div class="col-4 text-end">
                                        <a href="#">All Post</a>
                                    </div>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <td>
                                <a href="">আপনি কি জানেন?</a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="">ভুল করবেন না</a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">MD EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">MD EMON HASSAN</a></i></div>
        </div>
    </footer>
</div>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/livewire/main-body.blade.php ENDPATH**/ ?>