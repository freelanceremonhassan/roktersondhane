   <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(url('assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/fontawesome/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/javascript.js')); ?>"></script>
<?php if(Session::has('succ_message')): ?>
    <script>
        swal("Great Job..!", "<?php echo Session::get('succ_message'); ?>", "success", {
            button:"OK",
        })
    </script>
    <?php elseif(Session::has('err_message')): ?>
    <script>
        swal("Sorry..!", "<?php echo Session::get('err_message'); ?>", "error", {
            button:"OK",
        })
    </script>
<?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/footer.blade.php ENDPATH**/ ?>