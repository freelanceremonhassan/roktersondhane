
<?php $__env->startSection('title', 'Admin Panel'); ?>
<?php $__env->startSection('content'); ?>
    

    <div class="container-fluid">
        <div class="col-md-12 row">
            <div class="col-md-2 bg-secondary text-light">
                <div class="col-12 text-center mt-3">
                    <a href="/"><img src="<?php echo e(url('images/logo/WDC.jpg')); ?>" style="width: 100px; height:100px; border-radius: 50%;" alt=""></a>
                    <p class="text-center fw-bold mt-2">Rokter Sondhane</p>
                    <p>-<i>Developed by MD EMON HASSAN</i></p>
                </div>
                <div class="p-md-2 mt-md-3 mb-md-5">
                    <form action="">
                        <div class="form-group">
                            <select name="status" class="form-control mt-1" id="unavailable_donar">
                                <option value="all">All</option>
                                <option value="available">Available</option>
                                <option value="select_one" disabled>---Unavailable---</option>
                                <option value="under_age">Under Age</option>
                                <option value="under_weight">Under Weight</option>
                                <option value="already_donated">Already donated</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-10">
                <section class="container">
                    <div class="mx-auto my-4">
                        <div class="text-start">
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                Create Blog Post
                            </button>
                            
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Create Blog Post</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-12">
                                            <form action="/blog-post" method="post" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <input type="text" name="blog_title" id="blog_title" placeholder="Write Tittle" class="form-control">
                                                </div>
                                                <div class="form-group my-3">
                                                    <input type="file" name="blog_image" id="blog_image" placeholder="Enter Blog Image" class="form-control">
                                                </div>
                                                <div class="form-group">
                                                    <textarea name="blog_content" id="blog_content" cols="30" rows="6" class="form-control"></textarea>
                                                </div>
                                                <div class="text-end">
                                                    <input type="submit" value="Post" class="btn btn-primary mt-3">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-4 float-end">
                                <form action="" method="post">
                                    <div class="input-group">
                                        <input type="text" name="search" id="search" class="form-control">
                                        <button type="submit" class="input-group-text bg-primary text-light">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div>
                            <table class="table table-striped text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Blood Group</th>
                                    <th>Operation</th>
                                </tr>
                                <?php $__currentLoopData = $donars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->blood_group); ?></td>
                                        <td>
                                            <a href="<?php echo e($item->id); ?>" class="btn btn-success" data-toggle="modal" data-target="#donar_profile_information"><i class="fa fa-book-open"></i></a>
                                            <a href="#" class="btn btn-danger"><i class="fa fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                        <!-- View Donar Profiel Information Modal -->
                                        <div class="modal fade" id="donar_profile_information" tabindex="-1" aria-labelledby="donar_profile_informationLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                <h5 class="modal-title" id="donar_profile_informationLabel">Modal title</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                                </div>
                                                <div class="modal-body">
                                                    <?php echo e($item->id); ?>

                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <div class="container text-center">
                                <?php echo e($donars->links()); ?>

                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/admin-panel.blade.php ENDPATH**/ ?>