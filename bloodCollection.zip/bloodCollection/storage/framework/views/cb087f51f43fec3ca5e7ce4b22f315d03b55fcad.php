
<?php $__env->startSection('title', 'View Profile'); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="container">
        <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="col-12 text-end">
                        <a href="/" class="text-danger"><span><<</span> Go To Home Page</a>
                    </div>
                    <?php $__currentLoopData = $allDonar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-center mt-5">
                            <img src="<?php echo e(asset('images/profile_images')); ?>/<?php echo e($information->image); ?>" style="width: 150px; height:150px; border-radius: 50%;" alt="" class="">
                            <p class="h5 text-dark text-center mt-3"><?php echo e($information->name); ?></p>
                        </div>
                        <div class="text-center">
                            <a href="tel:<?php echo e($information->phone); ?>" class="btn btn-danger w-md-25"><i class="fa fa-phone"></i>Call Now</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="text-center mt-3">
                        <table class="table table-striped">
                            <tr class="text-danger">
                                <th>Last Donated</th>
                                <th>Available After</th>
                                <th>Donated</th>
                            </tr>
                            <?php $__currentLoopData = $allDonar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <?php if($information->last_donate == ""|null): ?>
                                            <td>Null</td>
                                            <?php else: ?>
                                                <td><?php echo e($information->last_donate); ?></td>
                                        <?php endif; ?>
                                    <td>Null</td>
                                    <td>Null</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
        </div>
    </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-center">Posts</h4>
                        </div>
                        <div class="card-body row">
                            <?php $__currentLoopData = $selectedDonar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donarPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $allDonar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($donarPost->id == $item->id): ?>
                                        <div class="card posts">
                                            <a href="#" data-toggle="modal" data-target="#view_post_modal"><img src="<?php echo e(asset('images/post_image')); ?>/<?php echo e($donarPost->post_image); ?>" alt="<?php echo e($item->name); ?>" class="card-img-top" style="height:150px"></a>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <footer class="text-center fixed-bottom container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">EMON HASSAN</a></i></div>
        </div>
    </footer>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/profile.blade.php ENDPATH**/ ?>