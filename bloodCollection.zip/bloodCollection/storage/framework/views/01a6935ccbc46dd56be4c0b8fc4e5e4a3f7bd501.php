
<?php $__env->startSection('title', 'Congratulations..!!!'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 offset-sm-3">
                <?php $__currentLoopData = $donar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="my-5">
                        <h1 class="text-success text-center">Congratulations..!!!</h1>
                        <p class="text-muted text-center">Now You are the member of "Rokter Sondhane". Please go to Homepage</p>
                        <a href="/body/<?php echo e($item->id); ?>" class="btn btn-primary">Go to Homepage</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/congratulations.blade.php ENDPATH**/ ?>