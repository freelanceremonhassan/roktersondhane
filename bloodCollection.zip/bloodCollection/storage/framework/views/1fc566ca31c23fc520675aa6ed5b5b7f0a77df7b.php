
<?php $__env->startSection('title', 'Search Result'); ?>
<?php $__env->startSection('content'); ?>
    

    <div class="container">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <div class="col-12 row mb-3 pt-3">
                    <div class="col-12 text-center">
                        <a href="/" class="text-danger"><span><<</span> Go To Home Page</a>
                    </div>
                </div>
                
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Blood Group</th>
                            <th>District</th>
                            <th>Thana</th>
                            <th>Call Donar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blood; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($donar->name); ?></td>
                                <td><?php echo e($donar->blood_group); ?></td>
                                <td><?php echo e($donar->district); ?></td>
                                <td><?php echo e($donar->thana); ?></td>
                                <td><a href="tel:<?php echo e($donar->phone); ?>" class="btn btn-primary"><i class="fa fa-phone"></i> Call</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <button class="btn btn-warning d-none" id="topBtn"><i class="fa fa-arrow-up"></i></button>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/search-donar.blade.php ENDPATH**/ ?>