
<?php $__env->startSection('title', 'Blog Posts'); ?>
<?php $__env->startSection('content'); ?>
    
    
    <div class="container">
        <div class="text-end pt-3">
            <a href="/"><span><< </span>Go Back to Home</a>
        </div>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-2">
                <h5 class="text-center text-danger" style="text-decoration: underline"><?php echo e($item->title); ?></h5>
                <?php if($item->blog_image): ?>
                    <img src="<?php echo e(asset('images/blog_images')); ?>/<?php echo e($item->blog_image); ?>" alt="<?php echo e($item->title); ?>" style="float:left; width: 200px; height: 200px; margin-right: 5px;">
                <?php endif; ?>
                <p class="text-dark" style="font-family: tahoma; font-size: 12pt">
                    <?php echo e($item->blog_content); ?>

                </p>
            </div>
            <hr class="text-danger">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($post->links()); ?>

    </div>
    <footer class="text-center container-fluid">
        <div class="bg-light row">
            <div class="col-md-6 text-dark fw-bold">Developed by -<i><a href="https://www.facebook.com/programmer.balok/" target="_blank">MD EMON HASSAN</a></i></div>
            <div class="col-md-6 fw-bold">প্রয়োজনে যোগাযোগ করুনঃ <i><a href="https://www.facebook.com/programmer.balok/" target="_blank">MD EMON HASSAN</a></i></div>
        </div>
    </footer>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bloodCollection\resources\views/all-post.blade.php ENDPATH**/ ?>